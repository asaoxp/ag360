import React from 'react';

const AIMode = ({ zones, toggleAI }) => {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">AI Prediction Mode</h2>
      <p className="mb-6">LSTM/ML prediction-based irrigation control</p>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
        <h3 className="font-bold text-blue-800">AI Insights</h3>
        <p className="text-blue-700">Based on weather forecasts and soil data, irrigation is recommended for tomorrow morning.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {zones.map(zone => (
          <div key={zone.id} className="border border-gray-200 rounded-lg p-4">
            <h3 className="text-xl font-bold mb-3">{zone.name}</h3>
            <div className="flex items-center justify-between mb-3">
              <span>AI Control</span>
              <button
                onClick={() => toggleAI(zone.id)}
                className={`w-12 h-6 rounded-full p-1 transition-colors duration-300 ease-in-out ${zone.aiEnabled ? 'bg-green-500' : 'bg-gray-300'}`}
              >
                <div className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform duration-300 ease-in-out ${zone.aiEnabled ? 'translate-x-6' : ''}`}></div>
              </button>
            </div>
            <div className="text-sm">
              <div className="mb-1">Next watering: <span className="font-bold">Tomorrow 6:00 AM</span></div>
              <div>Confidence: <span className="font-bold">92%</span></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AIMode;