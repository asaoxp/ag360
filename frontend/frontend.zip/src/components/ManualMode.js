import React from 'react';

const ManualMode = ({ zones, toggleManual }) => {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Manual Control</h2>
      <p className="mb-6">Toggle pumps/valves on or off for each zone</p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {zones.filter(zone => zone.id === 'A' || zone.id === 'B').map(zone => (
          <div key={zone.id} className="border border-gray-200 rounded-lg p-4">
            <h3 className="text-xl font-bold mb-3">{zone.name}</h3>
            <div className="flex items-center justify-between">
              <span>Water Pump</span>
              <button
                onClick={() => toggleManual(zone.id)}
                className={`w-12 h-6 rounded-full p-1 transition-colors duration-300 ease-in-out ${zone.manualOn ? 'bg-green-500' : 'bg-gray-300'}`}
              >
                <div className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform duration-300 ease-in-out ${zone.manualOn ? 'translate-x-6' : ''}`}></div>
              </button>
            </div>
            <div className="mt-4 text-sm text-gray-500">
              Status: {zone.manualOn ? 'ON' : 'OFF'}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ManualMode;