import React from 'react';

const AutoMode = ({ zones, timing, setTiming, updateThreshold }) => {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Automatic Mode</h2>
      <p className="mb-6">Set soil moisture thresholds for automatic irrigation</p>

      <div className="mb-6">
        <label className="block text-lg font-medium mb-2">Timing Intervals</label>
        <div className="flex gap-4">
          <div>
            <label className="block text-sm text-gray-500 mb-1">Start Time</label>
            <input
              type="time"
              value={timing.start}
              onChange={(e) => setTiming({...timing, start: e.target.value})}
              className="border border-gray-300 rounded p-2"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-500 mb-1">End Time</label>
            <input
              type="time"
              value={timing.end}
              onChange={(e) => setTiming({...timing, end: e.target.value})}
              className="border border-gray-300 rounded p-2"
            />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {zones.map(zone => (
          <div key={zone.id} className="border border-gray-200 rounded-lg p-4">
            <h3 className="text-xl font-bold mb-3">{zone.name}</h3>
            <div className="mb-3">
              <label className="block text-sm text-gray-500 mb-1">Moisture Threshold (%)</label>
              <input
                type="range"
                min="0"
                max="100"
                value={zone.autoThreshold}
                onChange={(e) => updateThreshold(zone.id, parseInt(e.target.value))}
                className="w-full"
              />
              <div className="flex justify-between text-sm text-gray-500">
                <span>0%</span>
                <span className="font-bold">{zone.autoThreshold}%</span>
                <span>100%</span>
              </div>
            </div>
            <div className="mt-4 text-sm">
              Current Soil Moisture: <span className="font-bold">42%</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AutoMode;