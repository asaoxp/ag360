import React, { useState } from 'react';
import useMqttPublish from '../hooks/useMqttPublish';
import ManualMode from '../components/ManualMode';
import AutoMode from '../components/AutoMode';
import AIMode from '../components/AIMode';

const IrrigationControl = () => {
  const [activeTab, setActiveTab] = useState('manual');
  const [zones, setZones] = useState([
    { id: 'A', name: 'Zone A', manualOn: false, autoThreshold: 30, aiEnabled: true },
    { id: 'B', name: 'Zone B', manualOn: false, autoThreshold: 25, aiEnabled: true },
    { id: 'C', name: 'Zone C', manualOn: false, autoThreshold: 35, aiEnabled: false }
  ]);
  const [timing, setTiming] = useState({ start: '06:00', end: '07:00' });

  const publish = useMqttPublish();

  const toggleManual = (zoneId) => {
    setZones(zones.map(zone => {
      if (zone.id === zoneId) {
        const newState = !zone.manualOn;
        // Publish MQTT message for zones A and B
        if (zoneId === 'A') {
          publish('esp32/relay1', newState ? '1' : '0');
        } else if (zoneId === 'B') {
          publish('esp32/relay2', newState ? '1' : '0');
        }
        return { ...zone, manualOn: newState };
      }
      return zone;
    }));
  };

  const updateThreshold = (zoneId, value) => {
    setZones(zones.map(zone => 
      zone.id === zoneId ? { ...zone, autoThreshold: value } : zone
    ));
  };

  const toggleAI = (zoneId) => {
    setZones(zones.map(zone => 
      zone.id === zoneId ? { ...zone, aiEnabled: !zone.aiEnabled } : zone
    ));
  };

  return (
    <div className="py-8">
      <h1 className="text-3xl font-bold text-green-700 mb-6">Irrigation Control</h1>
      
      <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
        <div className="flex border-b border-gray-200 mb-6">
          <button 
            className={`py-2 px-4 font-semibold ${activeTab === 'manual' ? 'text-green-600 border-b-2 border-green-600' : 'text-gray-500'}`}
            onClick={() => setActiveTab('manual')}
          >
            🔘 Manual Mode
          </button>
          <button 
            className={`py-2 px-4 font-semibold ${activeTab === 'auto' ? 'text-green-6000 border-b-2 border-green-600' : 'text-gray-500'}`}
            onClick={() => setActiveTab('auto')}
          >
            🔘 Automatic Mode
          </button>
          <button 
            className={`py-2 px-4 font-semibold ${activeTab === 'ai' ? 'text-green-600 border-b-2 border-green-600' : 'text-gray-500'}`}
            onClick={() => setActiveTab('ai')}
          >
            🤖 AI Mode
          </button>
        </div>
        
        {activeTab === 'manual' && (
          <ManualMode zones={zones} toggleManual={toggleManual} />
        )}
        
        {activeTab === 'auto' && (
          <AutoMode zones={zones} timing={timing} setTiming={setTiming} updateThreshold={updateThreshold} />
        )}
        
        {activeTab === 'ai' && (
          <AIMode zones={zones} toggleAI={toggleAI} />
        )}
      </div>
      
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h2 className="text-2xl font-bold mb-4">Irrigation History</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Zone</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Duration</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              <tr>
                <td className="px-6 py-4 whitespace-nowrap">2023-06-15</td>
                <td className="px-6 py-4 whitespace-nowrap">Zone A</td>
                <td className="px-6 py-4 whitespace-nowrap">25 min</td>
                <td className="px-6 py-4 whitespace-nowrap">Manual</td>
              </tr>
              <tr>
                <td className="px-6 py-4 whitespace-nowrap">2023-06-15</td>
                <td className="px-6 py-4 whitespace-nowrap">Zone B</td>
                <td className="px-6 py-4 whitespace-nowrap">18 min</td>
                <td className="px-6 py-4 whitespace-nowrap">Automatic</td>
              </tr>
              <tr>
                <td className="px-6 py-4 whitespace-nowrap">2023-06-14</td>
                <td className="px-6 py-4 whitespace-nowrap">Zone A</td>
                <td className="px-6 py-4 whitespace-nowrap">30 min</td>
                <td className="px-6 py-4 whitespace-nowrap">AI Predicted</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default IrrigationControl;